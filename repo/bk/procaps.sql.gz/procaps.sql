-- ---------------------------------------------------------
	--
	-- SIMPLE SQL Dump
	-- 
	-- http://www.nawa.me/
	--
	-- Host Connection Info: 127.0.0.1 via TCP/IP
	-- Generation Time: November 18, 2015 at 05:19 AM ( America/Bogota )
	-- Server version: 5.0.27-community-nt
	-- PHP Version: 5.5.15
	--
	-- ---------------------------------------------------------


	
	SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
	SET time_zone = "+00:00";
	
	
	/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
	/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
	/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
	/*!40101 SET NAMES utf8 */;
	

	-- ---------------------------------------------------------
	--
	-- Table structure for table : `categorias`
	--
	-- ---------------------------------------------------------
	
	CREATE TABLE `categorias` (
  `id` bigint(11) NOT NULL auto_increment,
  `talleres_id` bigint(11) NOT NULL,
  `nombre` varchar(64) NOT NULL,
  `color` varchar(7) NOT NULL,
  `dependencia` bigint(11) NOT NULL,
  `tiposcategoria_id` bigint(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_categoria_talleres_idx` (`talleres_id`),
  KEY `fk_categorias_tiposcategoria1_idx` (`tiposcategoria_id`),
  CONSTRAINT `fk_categorias_tiposcategoria1` FOREIGN KEY (`tiposcategoria_id`) REFERENCES `tiposcategoria` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_categoria_talleres` FOREIGN KEY (`talleres_id`) REFERENCES `talleres` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

	--
	-- Dumping data for table `categorias`
	--
	
	INSERT INTO `categorias` (`id`, `talleres_id`, `nombre`, `color`, `dependencia`, `tiposcategoria_id`) VALUES
(0, 0, '', '#FFFFFF', 0, 4),
(1, 1, 'Inexistente', '#EE1DAC', 0, 3),
(2, 1, 'Perfecto', '#5FBB46', 0, 1),
(3, 1, 'Regular', '#FFDF18', 0, 1),
(4, 1, 'Malo', '#EE1D23', 0, 1),
(5, 1, 'Acciones propuestas', '#528EF7', 3, 2),
(6, 1, 'X qu� definitivamente no funciona', '#F7931D', 4, 2);



	-- ---------------------------------------------------------
	--
	-- Table structure for table : `mesas`
	--
	-- ---------------------------------------------------------
	
	CREATE TABLE `mesas` (
  `id` bigint(11) NOT NULL auto_increment,
  `nombre` varchar(45) NOT NULL,
  `visiblesugerencias` tinyint(1) NOT NULL default '0',
  `talleres_id` bigint(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_mesas_talleres1_idx` (`talleres_id`),
  CONSTRAINT `fk_mesas_talleres1` FOREIGN KEY (`talleres_id`) REFERENCES `talleres` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

	--
	-- Dumping data for table `mesas`
	--
	
	INSERT INTO `mesas` (`id`, `nombre`, `visiblesugerencias`, `talleres_id`) VALUES
(1, 'RECURSOS FINANCIEROS', 0, 1),
(2, 'GESTION DE CALIDAD', 0, 1),
(3, 'INNOVACION Y DESARROLLO', 0, 1),
(4, 'LOGISTICA DE ABASTECIMIENTO', 0, 1),
(5, 'DISTRIBUCCION', 0, 1),
(6, 'GESTION COMERCIAL', 0, 1),
(7, 'PRODUCCION', 0, 1);



	-- ---------------------------------------------------------
	--
	-- Table structure for table : `procesos`
	--
	-- ---------------------------------------------------------
	
	CREATE TABLE `procesos` (
  `id` bigint(11) NOT NULL auto_increment,
  `proceso` text NOT NULL,
  `sugerencia` text NOT NULL,
  `fecha` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `mesas_id` bigint(11) NOT NULL,
  `categorias_id` bigint(11) NOT NULL,
  `talleres_id` bigint(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_procesos_talleres1_idx` (`talleres_id`),
  KEY `fk_procesos_categorias1_idx` (`categorias_id`),
  KEY `fk_procesos_mesas1_idx` (`mesas_id`),
  CONSTRAINT `fk_procesos_categorias1` FOREIGN KEY (`categorias_id`) REFERENCES `categorias` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_procesos_mesas1` FOREIGN KEY (`mesas_id`) REFERENCES `mesas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_procesos_talleres1` FOREIGN KEY (`talleres_id`) REFERENCES `talleres` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

	--
	-- Dumping data for table `procesos`
	--
	
	INSERT INTO `procesos` (`id`, `proceso`, `sugerencia`, `fecha`, `mesas_id`, `categorias_id`, `talleres_id`) VALUES
(1, 'Administraci�n Datos Maestros de Subreparto', '', '2015-11-09 08:34:14', 1, 4, 1),
(2, 'Administraci�n de Datos Maestros Centros de Beneficio', '', '2015-11-09 08:34:25', 1, 2, 1),
(3, 'Planificaci�n de Gastos en Centro de Costos', '', '2015-11-09 08:34:25', 1, 3, 1),
(4, 'Planificaci�n de Ordenes de CO', '', '2015-11-09 08:34:42', 1, 3, 1),
(5, 'Administraci�n Clase de Costo Secundario para Subreparto', '', '2015-11-09 08:34:51', 1, 3, 1),
(6, 'Administraci�n de Clase de Costo', '', '2015-11-09 08:34:25', 1, 4, 1),
(7, 'Administraci�n de Centros de Costo', '', '2015-11-09 08:34:25', 1, 3, 1),
(8, 'Administraci�n de �rdenes CO', '', '2015-11-09 08:34:25', 1, 2, 1),
(9, 'Gesti�n de Cr�dito', 'mis comentarios', '2015-11-09 08:34:25', 1, 5, 1),
(10, 'Notas Cr�dito y Notas D�bito', '', '2015-11-09 08:34:25', 1, 4, 1),
(11, 'Deudores Nacionales y Del Exterior', '', '2015-11-09 08:34:25', 1, 3, 1),
(12, 'Pagos Anticipados de Clientes', '', '2015-11-09 08:34:25', 1, 3, 1),
(13, 'Activaci�n de Datos Maestros Deudores', '', '2015-11-09 08:34:25', 1, 4, 1),
(14, 'Gesti�n de Pagos', '', '2015-11-09 08:34:25', 1, 4, 1),
(15, 'Operaciones de Caja Menor', '', '2015-11-09 08:34:25', 1, 4, 1),
(16, 'Administraci�n Datos Maestros de Bancos', '', '2015-11-09 08:34:25', 1, 4, 1),
(17, 'Conciliaciones Bancarias', 'nuevo orange comentario', '2015-11-09 08:34:25', 1, 6, 1),
(18, 'Cierre de Periodo', 'Prueba', '2015-11-09 08:34:25', 1, 5, 1),
(19, 'Clase de Costo Secundario para Actividad y Recargo', '', '2015-11-09 08:34:51', 1, 2, 1),
(20, 'Cotizaciones CO', '', '2015-11-09 08:34:25', 1, 2, 1),
(21, 'Datos Maestros Clase de Actividades', '', '2015-11-09 08:34:25', 1, 3, 1),
(22, 'Datos Maestros Valores Estad�sticos para Producci�n', '', '2015-11-09 08:34:25', 1, 2, 1),
(23, 'Planificaci�n de Costos de Producto', '', '2015-11-09 08:34:25', 1, 2, 1),
(24, 'Planificaci�n de Tarifas y Volumenes en Calidad y Producci�n', '', '2015-11-09 08:34:25', 1, 2, 1),
(25, 'Liquidaci�n de Ordenes de Fabricacion CO y Orden de Proceso Costo Variable', '', '2015-11-09 08:34:25', 1, 2, 1),
(26, 'Pre Cierre de Periodo', '', '2015-11-09 08:34:25', 1, 2, 1),
(27, 'Acreedores', 'Nueva plana', '2015-11-09 08:34:51', 1, 6, 1),
(28, 'Legalizaci�n de Gastos ', '', '2015-11-09 08:34:25', 1, 3, 1),
(29, 'Gesti�n Contable', '', '2015-11-09 08:34:25', 1, 4, 1),
(30, 'Administraci�n de Propiedad, Planta y Equipos PP&E', '', '2015-11-09 08:34:25', 1, 2, 1),
(31, 'Administraci�n de Datos Maestros Gesti�n Contable', '', '2015-11-09 08:34:51', 1, 3, 1),
(32, 'Administraci�n de Datos Maestros Activos Fijos', '', '2015-11-09 08:34:25', 1, 2, 1),
(33, 'Administraci�n de Datos Maestros Acreedores', '', '2015-11-09 08:34:25', 1, 2, 1),
(34, 'Planeaci�n Tributaria', '', '2015-11-09 08:34:25', 1, 4, 1),
(35, 'Declaraciones Tributarias', '', '2015-11-09 08:34:25', 1, 3, 1),
(36, 'Administraci�n Datos Maestros para Asignaci�n de C�digos', '', '2015-11-09 14:25:25', 2, 0, 1),
(37, 'Administraci�n  Datos Maestros de Calidad', '', '2015-11-09 14:25:41', 2, 0, 1),
(38, 'Administraci�n datos de Versiones de fabricaci�n', '', '2015-11-09 14:25:41', 2, 0, 1),
(39, 'Administraci�n Datos recetas de planificaci�n', '', '2015-11-09 14:25:41', 2, 0, 1),
(40, 'Administraci�n  Datos  lista de materiales', '', '2015-11-09 14:25:41', 2, 0, 1),
(41, 'Administraci�n Datos  recursos de fabricaci�n', '', '2015-11-09 14:25:41', 2, 0, 1),
(42, 'Aviso de Calidad Q1 � Evento Interno. ', '', '2015-11-09 14:25:41', 2, 0, 1),
(43, 'Gesti�n de Muestras F�sicas', '', '2015-11-09 14:25:41', 2, 0, 1),
(44, 'Inspecci�n en Devoluciones de Clientes', '', '2015-11-09 14:25:41', 2, 0, 1),
(45, 'Inspecci�n en traslado entre Centros', '', '2015-11-09 14:25:41', 2, 0, 1),
(46, 'Inspecci�n Peri�dica y Vencimiento de Materiales', '', '2015-11-09 14:25:41', 2, 0, 1),
(47, 'Inspecciones no planificadas', '', '2015-11-09 14:25:41', 2, 0, 1),
(48, 'Otras Inspecciones', '', '2015-11-09 14:25:41', 2, 0, 1),
(49, 'Calidad en Compras Importados', '', '2015-11-09 14:25:41', 2, 0, 1),
(50, 'Calidad en Compras Nacionales', '', '2015-11-09 14:25:41', 2, 0, 1),
(51, 'Certificados de calidad', '', '2015-11-09 14:25:41', 2, 0, 1),
(52, 'Confirmaci�n y liberaci�n Producto fabricado', '', '2015-11-09 14:26:17', 2, 0, 1),
(53, 'Control Proceso durante la Fabricaci�n', '', '2015-11-09 14:25:41', 2, 0, 1),
(54, 'Control de Calidad y Administraci�n de la Informaci�n de Producci�n ', '', '2015-11-09 14:26:17', 2, 0, 1),
(55, 'Administraci�n de Inventarios de Muestras en Retenci�n', '', '2015-11-09 14:26:17', 2, 0, 1),
(56, 'Recolecci�n de Producto del Mercado ', '', '2015-11-09 14:25:41', 2, 0, 1),
(57, 'Gesti�n del Sistema de Documentaci�n', '', '2015-11-09 14:25:41', 2, 0, 1),
(58, 'Planeaci�n y Seguimiento del Sistema de Calidad', '', '2015-11-09 14:26:17', 2, 0, 1),
(59, 'Gesti�n de Requisitos Legales', '', '2015-11-09 14:25:41', 2, 0, 1),
(60, 'Gesti�n Cotizaci�n Muestras', '', '2015-11-09 14:25:41', 2, 0, 1),
(61, 'Aviso de Calidad Q8 - Gesti�n de No Conformidades de Auditor�as', '', '2015-11-09 14:26:17', 2, 0, 1),
(62, 'Aviso de Calidad Q7 � Reclamo a Proveedores', '', '2015-11-09 14:26:17', 2, 0, 1),
(63, 'Administraci�n de Documentaci�n Externa', '', '2015-11-09 14:25:41', 2, 0, 1),
(64, 'Administraci�n de Acuerdos de Calidad de Terceros y Proveedores', '', '2015-11-09 14:25:41', 2, 0, 1),
(65, 'Auditoria a Proveedores', '', '2015-11-09 14:25:41', 2, 0, 1),
(66, 'Gesti�n de Acciones Correctivas, Preventivas y de Mejora', '', '2015-11-09 14:25:41', 2, 0, 1),
(67, 'Aviso de Calidad Q2 � Investigaciones', '', '2015-11-09 14:25:41', 2, 0, 1),
(68, 'Aviso de Calidad Q6 � Material no Conforme', '', '2015-11-09 14:25:41', 2, 0, 1),
(69, 'Aviso de Calidad Q4 � Reclamaci�n de Clientes', '', '2015-11-09 14:25:41', 2, 0, 1),
(70, 'Aviso de Calidad Q9 � Control de Cambio', '', '2015-11-09 14:25:41', 2, 0, 1),
(71, 'Revisi�n Anual de Producto ', '', '2015-11-09 14:25:41', 2, 0, 1),
(72, 'Administraci�n de Inventarios de Insumos de Laboratorio', '', '2015-11-09 14:25:41', 2, 0, 1),
(73, 'An�lisis de Calidad', '', '2015-11-09 14:25:41', 2, 0, 1),
(74, 'Aviso de Calidad Q5 � Fuera de Especificaciones y Fuera de Tendencia', '', '2015-11-09 14:26:17', 2, 0, 1),
(75, 'Calificaci�n de �reas, equipos y sistemas de apoyo cr�tico', '', '2015-11-09 14:25:41', 2, 0, 1),
(76, 'Validaciones ', '', '2015-11-09 14:25:41', 2, 0, 1),
(77, 'Validaci�n de M�todos Anal�ticos de Producto Terminado y Materia Prima', '', '2015-11-09 14:26:17', 2, 0, 1),
(78, 'Ciclo de Vida de Instrumentos de Medici�n', '', '2015-11-09 14:25:41', 2, 0, 1),
(79, 'Gesti�n de Screening y DIM (Hoja de vida del producto)', '', '2015-11-09 14:25:41', 3, 0, 1),
(80, 'Licenciamiento', '', '2015-11-09 14:26:17', 3, 0, 1),
(81, 'Fabricacion de lote Piloto ', '', '2015-11-09 14:25:41', 3, 0, 1),
(82, 'Estudio de Estabilidades', '', '2015-11-09 14:25:41', 3, 0, 1),
(83, 'Lanzamiento de Productos de Desarrollo', '', '2015-11-09 14:25:41', 3, 0, 1),
(84, 'Lanzamiento de Productos Licenciados', '', '2015-11-09 14:25:41', 3, 0, 1),
(85, 'Lanzamiento de Productos Extensi�n de L�nea', '', '2015-11-09 14:26:17', 3, 0, 1),
(86, 'Preformulaci�n ', '', '2015-11-09 14:25:41', 3, 0, 1),
(87, 'Formulaci�n ', '', '2015-11-09 14:26:17', 3, 0, 1),
(88, 'Transferencia Analitica', '', '2015-11-09 14:25:41', 3, 0, 1),
(89, 'Transferencia a Manufactura y Empaque', '', '2015-11-09 14:25:41', 3, 0, 1),
(90, 'Desarrollo Anal�tico ', '', '2015-11-09 14:25:41', 3, 0, 1),
(91, 'Desarrollo de Empaques para Nuevos Productos', '', '2015-11-09 14:25:41', 3, 0, 1),
(92, 'Administraci�n de Proyectos para Nuevos Productos', '', '2015-11-09 14:26:17', 3, 0, 1),
(93, 'Contabilizaci�n del PDS', '', '2015-11-09 14:25:41', 3, 0, 1),
(94, 'Planificaci�n de Tarifas de Actividades en PDS', '', '2015-11-09 14:25:41', 3, 0, 1),
(95, 'Creaci�n de Ordenes de Fabricaci�n CO', '', '2015-11-09 14:26:17', 3, 0, 1),
(96, 'Generaci�n de Documentaci�n Desarrollo de Nuevos Productos', '', '2015-11-09 14:26:17', 3, 0, 1),
(97, 'Generaci�n de Artes ', '', '2015-11-09 14:25:41', 3, 0, 1),
(98, 'Planificaci�n Log�stica', '', '2015-11-09 14:25:41', 4, 0, 1),
(99, 'Selecci�n y Aprobaci�n de Proveedores', '', '2015-11-09 14:25:41', 4, 0, 1),
(100, 'Evaluaci�n de Proveedores', '', '2015-11-09 14:25:41', 4, 0, 1),
(101, 'Conciliaci�n de Cuentas con Proveedores', '', '2015-11-09 14:25:41', 4, 0, 1),
(102, 'Compras de Activos Fijos', '', '2015-11-09 14:26:17', 4, 0, 1),
(103, 'Compras de Servicios Imputadas al Gasto', '', '2015-11-09 14:26:17', 4, 0, 1),
(104, 'Compra de Material Publicitario', '', '2015-11-09 14:25:41', 4, 0, 1),
(105, 'Devoluci�n a Proveedores', '', '2015-11-09 14:25:41', 4, 0, 1),
(106, 'Subcontrataci�n', '', '2015-11-09 14:25:41', 4, 0, 1),
(107, 'Compra de Bienes', '', '2015-11-09 14:25:41', 4, 0, 1),
(108, 'Compras de Bienes Imputadas al Gasto', '', '2015-11-09 14:25:41', 4, 0, 1),
(109, 'Compras de Servicios Especiales', '', '2015-11-09 14:25:41', 4, 0, 1),
(110, 'Creaci�n de Contrato Marco', '', '2015-11-09 14:25:41', 4, 0, 1),
(111, 'Petici�n de Oferta', '', '2015-11-09 14:25:41', 4, 0, 1),
(112, 'Subcontrataci�n Intercompany', '', '2015-11-09 14:25:41', 4, 0, 1),
(113, 'Tr�mite Inscripci�n INCODER', '', '2015-11-09 14:25:41', 4, 0, 1),
(114, 'Tr�mite Re Importaci�n', '', '2015-11-09 14:25:41', 4, 0, 1),
(115, 'Tr�mite autorizaciones INVIMA', '', '2015-11-09 14:25:41', 4, 0, 1),
(116, 'Tramite Permisos ICA', '', '2015-11-09 14:25:41', 4, 0, 1),
(117, 'Tramite Permisos FNE ', '', '2015-11-09 14:25:41', 4, 0, 1),
(118, 'Tramite Registros de Importacion', '', '2015-11-09 14:25:41', 4, 0, 1),
(119, 'Importaciones', '', '2015-11-09 14:25:41', 4, 0, 1),
(120, 'Creacion de Insumos y Productos ', '', '2015-11-09 14:25:41', 4, 0, 1),
(121, 'Control de Saldos', '', '2015-11-09 14:25:41', 4, 0, 1),
(122, 'Otros Movimientos de Mercanc�as MM', '', '2015-11-09 14:25:41', 4, 0, 1),
(123, 'Inventarios WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(124, 'Traslados de Materiales entre Centros y Almacenes WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(125, 'Entrada y Almacenamiento de Semielaborados y Productos Terminados WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(126, 'Entrada de Mercanc�a de Proveedores WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(127, 'Alistamiento de Mercanc�a para Ordenes de Producci�n WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(128, 'Administraci�n de Materiales Controlados WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(129, 'Devoluci�n de Materiales Entregados a Producci�n WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(130, 'Otros Movimientos de Mercanc�as WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(131, 'Almacenamiento de Mercancias WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(132, 'Alistamiento de Mercanc�a para Ordenes de Fabricaci�n y Consumo MM', '', '2015-11-09 14:25:41', 4, 0, 1),
(133, 'Almacenamiento de Mercanc�as Recibidas MM', '', '2015-11-09 14:25:41', 4, 0, 1),
(134, 'Devoluci�n de Producci�n MM', '', '2015-11-09 14:25:41', 4, 0, 1),
(135, 'Entrada de Mercanc�as MM', '', '2015-11-09 14:25:41', 4, 0, 1),
(136, 'Entrada de Semielaborados y Productos Terminados MM', '', '2015-11-09 14:25:41', 4, 0, 1),
(137, 'Gastos de Operador Log�stico', '', '2015-11-09 14:25:41', 4, 0, 1),
(138, 'Inventario ', '', '2015-11-09 14:25:41', 4, 0, 1),
(139, 'Traslados de Materiales entre Centros y Almacenes MM', '', '2015-11-09 14:25:41', 4, 0, 1),
(140, 'Entrada de Mercanc�a OPL (Operador Log�stico)', '', '2015-11-09 14:25:41', 4, 0, 1),
(141, 'Administraci�n Datos  de capacidad de las ubicaciones WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(142, 'Administraci�n Datos de ciclos de control WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(143, 'Anulaci�n de Entrada de Mercanc�a de Proveedores WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(144, 'Anulaci�n de Salida de Mercanc�a por Devoluci�n de Compra WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(145, 'Reabastecimiento de Tipos de Almacen de Ubicaci�n Fija en Producci�n WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(146, 'Alistamiento de Mercanc�as para Venta WM', '', '2015-11-09 14:25:41', 4, 0, 1),
(147, 'Ventas Mostrador', '', '2015-11-09 14:25:41', 4, 0, 1),
(148, 'Devoluci�n de Clientes', '', '2015-11-10 07:21:35', 5, 2, 1),
(149, 'Retoma y Facturaci�n de Venta en Consignaci�n', '', '2015-11-10 07:21:35', 5, 3, 1),
(150, 'Recibo y soluci�n de novedades', '', '2015-11-10 07:21:35', 5, 4, 1),
(151, 'Tr�mite Re Exportaci�n', 'Cambio', '2015-11-10 07:21:11', 5, 4, 1),
(152, 'Gesti�n de Distribuci�n', 'con data', '2015-11-10 07:21:35', 5, 6, 1),
(153, 'Refacturaci�n', '', '2015-11-10 07:21:35', 5, 3, 1),
(154, 'Transporte', 'Prueba', '2015-11-10 07:21:35', 5, 5, 1),
(155, 'Ventas Nacionales', '', '2015-11-02 14:54:32', 6, 0, 1),
(156, 'Cotizaciones SD', '', '2015-11-02 14:54:32', 6, 0, 1),
(157, 'Pedidos sin Cargo', '', '2015-11-02 14:54:32', 6, 0, 1),
(158, 'Ventas de Exportaci�n', '', '2015-11-02 14:54:32', 6, 0, 1),
(159, 'Ventas de Servicios', '', '2015-11-02 14:54:32', 6, 0, 1),
(160, 'Administraci�n Datos de Listas de Precios', '', '2015-11-02 14:54:32', 6, 0, 1),
(161, 'Tr�mite de Solicitudes de Beneficios de los Pacientes', '', '2015-11-02 14:54:32', 6, 0, 1),
(162, 'Plan de Marketing  (FARMA)', '', '2015-11-02 14:54:32', 6, 0, 1),
(163, 'Plan de Ventas  (FARMA)', '', '2015-11-02 14:54:32', 6, 0, 1),
(164, 'Generaci�n de Demanda (FARMA)', '', '2015-11-02 14:54:32', 6, 0, 1),
(165, 'Gesti�n de Demanda  (FARMA)', '', '2015-11-02 14:54:32', 6, 0, 1),
(166, 'Trade Marketing  (FARMA)', '', '2015-11-02 14:54:32', 6, 0, 1),
(167, 'Plan de Marketing (HOSPITALARIA)', '', '2015-11-02 14:54:32', 6, 0, 1),
(168, 'Plan de Ventas (HOSPITALARIA)', '', '2015-11-02 14:54:32', 6, 0, 1),
(169, 'Gesti�n de Demanda de Medicamentos (HOSPITALARIA)', '', '2015-11-02 14:54:32', 6, 0, 1),
(170, 'Gesti�n de Demanda Bioser (HOSPITALARIA)', '', '2015-11-02 14:54:32', 6, 0, 1),
(171, 'Licitaciones, Convocatoria y Contratos (Hospitalaria)', '', '2015-11-02 14:54:32', 6, 0, 1),
(172, 'Ventas en Consignaci�n', '', '2015-11-02 14:54:32', 6, 0, 1),
(173, 'Administraci�n Datos  de interlocutores', '', '2015-11-02 14:54:32', 6, 0, 1),
(174, 'Administraci�n datos de lista de materiales comercial', '', '2015-11-02 14:54:32', 6, 0, 1),
(175, 'Gesti�n de Demanda (Vital Care)', '', '2015-11-02 14:54:32', 6, 0, 1),
(176, 'Plan de Marketing (VITAL CARE)', '', '2015-11-02 14:54:32', 6, 0, 1),
(177, 'Trade Marketing (VITAL CARE)', '', '2015-11-02 14:54:32', 6, 0, 1),
(178, 'Plan de Ventas (VITAL CARE)', '', '2015-11-02 14:54:32', 6, 0, 1),
(179, 'Gesti�n Puntos de Venta (VITAL CARE)', '', '2015-11-02 14:54:32', 6, 0, 1),
(180, 'Plan de Ventas Diabetrics', '', '2015-11-02 14:54:32', 6, 0, 1),
(181, 'Plan de Ventas (SOFTIGEL)', '', '2015-11-02 14:54:32', 6, 0, 1),
(182, 'Preventa (SOFTIGEL)', '', '2015-11-02 14:54:32', 6, 0, 1),
(183, 'Administraci�n Datos de Impuestos a las Ventas', '', '2015-11-02 14:54:32', 6, 0, 1),
(184, 'Evaluaci�n de Sospecha de Reacci�n Adversa', '', '2015-11-02 14:54:32', 6, 0, 1),
(185, 'Vigilancia de Dispositivos M�dicos', '', '2015-11-02 14:54:32', 6, 0, 1),
(186, 'Fabricaci�n C�psula Blanda de Gelatina', '', '2015-11-09 08:34:25', 7, 0, 1),
(187, 'Fabricaci�n de Tabletas', '', '2015-11-09 08:34:25', 7, 0, 1),
(188, 'Fabricaci�n de L�quidos y Cremas', '', '2015-11-09 08:34:25', 7, 0, 1),
(189, 'Blisteado, Llenado y Empaque', '', '2015-11-09 08:34:25', 7, 0, 1),
(190, 'Fabricaci�n de Polvos', '', '2015-11-09 08:34:25', 7, 0, 1),
(191, 'Fabricaci�n de C�psula Dura', '', '2015-11-09 08:34:25', 7, 0, 1),
(192, 'Subcontrataci�n- Trabajo Externo', '', '2015-11-09 08:34:25', 7, 0, 1),
(193, 'Control de Piso', '', '2015-11-09 08:34:25', 7, 0, 1),
(194, 'Programaci�n de Personal de Planta ', '', '2015-11-09 08:34:25', 7, 0, 1),
(195, 'Administraci�n y Control de Ordenes y Materiales en Proceso', '', '2015-11-09 08:34:25', 7, 0, 1),
(196, 'Conciliaci�n y Cierre de Ordenes ', '', '2015-11-09 08:34:25', 7, 0, 1),
(197, 'Reprocesos y Retrabajos', '', '2015-11-09 08:34:25', 7, 0, 1),
(198, 'Subcontrataci�n- Trabajo Externo', '', '2015-11-09 08:34:25', 7, 0, 1),
(199, 'Control de Piso', '', '2015-11-09 08:34:25', 7, 0, 1),
(200, 'Conciliaci�n y Cierre de Ordenes ', '', '2015-11-09 08:34:25', 7, 0, 1),
(201, 'Reprocesos y Retrabajos', '', '2015-11-09 08:34:25', 7, 0, 1),
(202, 'An�lisis de Calidad', '', '2015-11-09 08:34:25', 7, 0, 1),
(203, 'Aviso de Calidad Q5 � Fuera de Especificaciones y Fuera de Tendencia', '', '2015-11-09 08:34:25', 7, 0, 1),
(204, 'plenaria', 'Plenaria 1', '2015-11-10 07:37:10', 1, 1, 1),
(205, 'plenaria', 'Plenaria 2', '2015-11-10 07:37:12', 1, 1, 1);



	-- ---------------------------------------------------------
	--
	-- Table structure for table : `talleres`
	--
	-- ---------------------------------------------------------
	
	CREATE TABLE `talleres` (
  `id` bigint(11) NOT NULL auto_increment,
  `nombre` varchar(128) NOT NULL,
  `fecha` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `titulo` varchar(64) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

	--
	-- Dumping data for table `talleres`
	--
	
	INSERT INTO `talleres` (`id`, `nombre`, `fecha`, `titulo`) VALUES
(0, 'init', '2015-11-02 14:51:39', '-'),
(1, 'Procaps', '2015-11-02 13:12:22', 'Taller de procesos');



	-- ---------------------------------------------------------
	--
	-- Table structure for table : `tiposcategoria`
	--
	-- ---------------------------------------------------------
	
	CREATE TABLE `tiposcategoria` (
  `id` bigint(11) NOT NULL auto_increment,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

	--
	-- Dumping data for table `tiposcategoria`
	--
	
	INSERT INTO `tiposcategoria` (`id`, `nombre`) VALUES
(1, 'principal'),
(2, 'sugerencia'),
(3, 'admin'),
(4, 'init');



	-- ---------------------------------------------------------
	--
	-- Table structure for table : `vwpregxmesa`
	--
	-- ---------------------------------------------------------
	
	CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwpregxmesa` AS select `p`.`mesas_id` AS `mesas_id`,`m`.`nombre` AS `nombre`,count(`p`.`mesas_id`) AS `total` from (`procesos` `p` left join `mesas` `m` on((`m`.`id` = `p`.`mesas_id`))) group by `p`.`mesas_id`;

	--
	-- Dumping data for table `vwpregxmesa`
	--
	
	INSERT INTO `vwpregxmesa` (`mesas_id`, `nombre`, `total`) VALUES
(1, 'RECURSOS FINANCIEROS', 37),
(2, 'GESTION DE CALIDAD', 43),
(3, 'INNOVACION Y DESARROLLO', 19),
(4, 'LOGISTICA DE ABASTECIMIENTO', 50),
(5, 'DISTRIBUCCION', 7),
(6, 'GESTION COMERCIAL', 31),
(7, 'PRODUCCION', 18);



	-- ---------------------------------------------------------
	--
	-- Table structure for table : `vwvotados`
	--
	-- ---------------------------------------------------------
	
	CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwvotados` AS select `p`.`categorias_id` AS `categorias_id`,count(`p`.`categorias_id`) AS `votados`,`p`.`mesas_id` AS `mesas_id`,`cat`.`nombre` AS `nombre`,`cat`.`dependencia` AS `dependencia`,`cat`.`color` AS `color` from (`procesos` `p` left join `categorias` `cat` on((`cat`.`id` = `p`.`categorias_id`))) where (`p`.`categorias_id` > 0) group by `p`.`categorias_id`,`p`.`mesas_id`;

	--
	-- Dumping data for table `vwvotados`
	--
	
	INSERT INTO `vwvotados` (`categorias_id`, `votados`, `mesas_id`, `nombre`, `dependencia`, `color`) VALUES
(1, 2, 1, 'Inexistente', 0, '#EE1DAC'),
(2, 12, 1, 'Perfecto', 0, '#5FBB46'),
(2, 1, 5, 'Perfecto', 0, '#5FBB46'),
(3, 10, 1, 'Regular', 0, '#FFDF18'),
(3, 2, 5, 'Regular', 0, '#FFDF18'),
(4, 9, 1, 'Malo', 0, '#EE1D23'),
(4, 2, 5, 'Malo', 0, '#EE1D23'),
(5, 2, 1, 'Acciones propuestas', 3, '#528EF7'),
(5, 1, 5, 'Acciones propuestas', 3, '#528EF7'),
(6, 2, 1, 'X qu� definitivamente no funciona', 4, '#F7931D'),
(6, 1, 5, 'X qu� definitivamente no funciona', 4, '#F7931D');


	/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
	/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
	/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;